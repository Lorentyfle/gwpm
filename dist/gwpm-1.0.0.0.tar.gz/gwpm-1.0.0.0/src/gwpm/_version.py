# GWPM version file

__version__ = "1.0.0.0"
